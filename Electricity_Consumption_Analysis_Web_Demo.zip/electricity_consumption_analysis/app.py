import streamlit as st
import pandas as pd
from pathlib import Path
st.set_page_config(page_title="Electricity Consumption Analysis", page_icon="⚡", layout="wide")
st.title("⚡ Electricity Consumption Analysis")
st.caption("Monthly usage dashboard · Python project demonstration")
data_path = Path(__file__).resolve().parent / "data" / "electricity_data.csv"
df = pd.read_csv(data_path)
df["Month"] = pd.to_datetime(df["Month"], format="%Y-%m")
df = df.sort_values("Month")
df["Month label"] = df["Month"].dt.strftime("%b %Y")
rate = st.sidebar.number_input("Rate per unit (₹/kWh)", min_value=0.0, value=6.0, step=0.5)
df["Estimated bill (₹)"] = df["Units_kWh"] * rate
a,b,c,d = st.columns(4)
a.metric("Total consumption", f"{df['Units_kWh'].sum():,.0f} kWh")
b.metric("Average monthly usage", f"{df['Units_kWh'].mean():,.1f} kWh")
c.metric("Estimated total bill", f"₹{df['Estimated bill (₹)'].sum():,.2f}")
high = df.loc[df['Units_kWh'].idxmax()]
d.metric("Highest usage", f"{high['Units_kWh']:.0f} kWh", high['Month label'])
left,right = st.columns(2)
with left:
 st.subheader("Monthly electricity consumption")
 st.bar_chart(df.set_index("Month label")["Units_kWh"])
with right:
 st.subheader("Consumption trend")
 st.line_chart(df.set_index("Month label")["Units_kWh"])
st.subheader("Estimated monthly electricity bill")
st.bar_chart(df.set_index("Month label")["Estimated bill (₹)"])
st.subheader("Monthly data")
st.dataframe(df[["Month label", "Units_kWh", "Estimated bill (₹)"]].rename(columns={"Month label":"Month", "Units_kWh":"Consumption (kWh)"}), use_container_width=True, hide_index=True)
st.caption("Sample project data. Bills use a flat rate and are estimates, not official utility calculations.")
